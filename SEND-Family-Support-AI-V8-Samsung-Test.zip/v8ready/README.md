# SEND Family Support AI V8 — Samsung Test Build

This package is prepared to minimise the technical work needed to test the Android version.

### Fastest route
Use the included GitHub Actions workflow:
`.github/workflows/build-apk.yml`

It automatically installs the Android SDK/Gradle build dependencies and produces a testable debug APK as a downloadable workflow artifact.

See `TEST-ON-SAMSUNG.md` for the step-by-step route.

### Android project
The Android project is in `android/` and wraps the V8 web app in a portrait WebView.

### Important
This is a prototype/test build. It is not a production release. Do not place API secrets in the app. For a public release, use HTTPS, authentication, proper consent/privacy controls, secure backend hosting, app signing and a production security review.
