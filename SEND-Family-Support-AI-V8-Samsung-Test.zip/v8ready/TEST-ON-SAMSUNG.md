# SEND Family Support AI V8 — easiest Samsung test route

## Recommended: build the APK automatically with GitHub

1. Create a free GitHub account if you do not already have one.
2. Create a new repository, for example `send-family-support-ai`.
3. Upload the contents of this folder to the repository (upload the files/folders, not the ZIP itself).
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and run the workflow.
6. When it finishes, open the workflow run and download the artifact named **SEND-Family-Support-AI-debug-apk**.
7. Extract the downloaded artifact on your Samsung and tap `app-debug.apk`.
8. If Android asks for permission to install an app from that source, only allow it if you trust the file/source. Google recommends using trusted sources; Android may apply additional developer-verification protections depending on device/region.
9. Install and open **SEND Family Support AI**.

The APK is a debug/test build, not a Play Store release. Android's documentation says debug APKs are suitable for immediate testing and are signed with a debug key. See the official Android build documentation for details.

## What works without a server

- Home dashboard
- Ask Support AI with built-in guidance
- Evidence Diary
- Evidence summary/export
- Learning Centre
- Profile
- Local data storage
- Import/export/delete local data
- Voice input where supported by the device/browser WebView

## Optional real AI connection

The app has an optional server-endpoint field in Profile. Do not put an OpenAI API key in the app. A production backend should hold the secret and expose a secure HTTPS endpoint.

## If you prefer Android Studio

Open the `android` folder in Android Studio, let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be in `android/app/build/outputs/apk/debug/`.
