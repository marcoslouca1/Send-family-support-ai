const DATA = {
 disclaimer: "Guidance only — not medical, legal, educational or benefits advice. Check current official guidance and speak to the relevant professional/service for decisions about your situation.",
 welcome: "You’re in the right place. Whether you’re noticing something for the first time, waiting for assessment, or already have a diagnosis, I can help you work through practical next steps one step at a time.",
 resources: [
  ["Early signs & assessment","https://www.nhs.uk/conditions/autism/signs-in-children/","NHS: signs of autism in children"],
  ["Autism assessment","https://www.nhs.uk/conditions/autism/assessments/","NHS: autism assessments"],
  ["Diagnosis for children","https://www.autismcentral.nhs.uk/guidance/diagnosis-children","Autism Central: diagnosis for children"],
  ["DLA for children","https://www.gov.uk/disability-living-allowance-children","GOV.UK: DLA for children"],
  ["PIP","https://www.gov.uk/pip","GOV.UK: Personal Independence Payment"],
  ["EHC/SEND help","https://www.gov.uk/children-with-special-educational-needs/extra-SEN-help","GOV.UK: extra SEN help"],
  ["Family Fund","https://www.familyfund.org.uk/","Family Fund"],
  ["Contact","https://contact.org.uk/","Contact"],
  ["National Autistic Society","https://www.autism.org.uk/","National Autistic Society"],
  ["IPSEA","https://www.ipsea.org.uk/","IPSEA"]
 ],
 topics:{
  dla:{title:"DLA for children",keys:["dla","disability living allowance"],answer:"DLA for children is generally for children under 16 who need much more looking after than a child of the same age or have difficulty walking, subject to the eligibility rules. In England and Wales, the current GOV.UK guidance is the place to check eligibility and claim steps.

A useful approach is to describe the extra care, prompting, supervision, communication help, mobility difficulties and how often these occur, using specific real-life examples. Your Evidence Diary can help organise those examples.

Official guide: https://www.gov.uk/disability-living-allowance-children

"},
  pip:{title:"PIP from age 16",keys:["pip","personal independence","turning 16"],answer:"PIP is for people aged 16 or over who meet the relevant eligibility rules. If a child receives DLA, GOV.UK explains what happens around age 16 and when they are invited to apply.

Focus on how difficulties affect everyday activities and getting around, with concrete examples of what happens, what help is needed and whether it can be done reliably.

Official guide: https://www.gov.uk/pip

"},
  ehcp:{title:"EHCP / EHC needs assessment",keys:["ehcp","ehc plan","education health"],answer:"If you think your child needs more support than can be provided through ordinary SEN Support, you can ask your local authority for an EHC needs assessment. GOV.UK explains the process and statutory timescales, including the 20-week overall timeframe for issuing a final plan in applicable cases.

Keep copies of reports, school communications and examples of the support your child needs.

Official guide: https://www.gov.uk/children-with-special-educational-needs/extra-SEN-help

"},
  assessment:{title:"Waiting for an autism assessment",keys:["assessment","waiting","autism"],answer:"While you are waiting, you do not have to wait for a diagnosis before asking what support is available. The NHS says support available while waiting can be discussed with a GP or education professional, and children may be referred through health or education routes depending on local arrangements.

Keep a short record of situations that are difficult, what support helps, and what happens afterwards.

NHS assessment information: https://www.nhs.uk/conditions/autism/assessments/

"},
  meltdown:{title:"Meltdowns and overwhelm",keys:["meltdown","overwhelm","shutdown","distress"],answer:"During intense distress, prioritise safety and reduce demands and sensory input where possible. Keep language short and calm, avoid trying to reason through everything in the moment, and reconnect once the person is regulated.

Afterwards, look for patterns: what happened before, what the environment was like, what helped and what could be changed next time.

If there is an immediate risk of serious harm, use appropriate urgent or emergency services rather than relying on this app.

"},
  sensory:{title:"Sensory needs",keys:["sensory","noise","touch","light","overstim"],answer:"Sensory differences can affect how someone experiences sound, touch, light, movement, smells and busy environments. Try to identify the specific trigger rather than assuming one strategy will work for everyone.

Useful diary prompts: trigger → signs of overload → what reduced the load → recovery time.

"},
  school:{title:"School and SEND support",keys:["school","senco","send","teacher"],answer:"Start by describing the functional impact: what your child finds difficult, what support is already tried, how often support is needed and what happens without it. A meeting with the SENCO can help turn this into a practical support plan.

If needs are not being met through ordinary SEN Support, you can ask the local authority about an EHC needs assessment.

"},
  support:{title:"You do not have to do everything at once",keys:["what next","next step","don't know","dont know"],answer:"Let’s make this smaller. Pick one thing that is causing the most pressure today. Then we can work through: 1) what is happening, 2) what support is already in place, 3) what is missing, 4) who can help, and 5) the next action you can realistically take.

You can also record the situation in your Evidence Diary so you do not have to remember everything later.

"}
 }
};