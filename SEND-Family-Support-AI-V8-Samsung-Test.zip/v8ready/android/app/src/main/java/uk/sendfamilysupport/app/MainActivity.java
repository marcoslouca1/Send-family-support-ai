package uk.sendfamilysupport.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.GeolocationPermissions;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState); WebView w=new WebView(this); setContentView(w); w.setWebViewClient(new WebViewClient()); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); w.setOverScrollMode(WebView.OVER_SCROLL_NEVER); w.loadUrl("file:///android_asset/index.html");}
}
