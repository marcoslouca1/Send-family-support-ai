# Build the Samsung APK on GitHub

Upload the contents of this folder to the ROOT of your GitHub repository. The `.github/workflows/build-apk.yml` file must also be at the repository root.

Then open **Actions** → **Build Android APK** → **Run workflow** → choose `main` → **Run workflow**.

When the run finishes, open the run and download the artifact named **SEND-Family-Support-AI-debug-apk**. Extract the APK and install it on the Samsung phone.
